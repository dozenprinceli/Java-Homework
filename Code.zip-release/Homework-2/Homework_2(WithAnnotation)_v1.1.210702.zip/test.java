public class test {
    public static void main(String[] args) {
        // char ch_a = 97;
        // char ch_A = 65;
        // System.out.println(ch_a);
        // System.out.println(ch_A);

        // if (user.cookie.agreed) {
        //     cookie.collect();
        // }else {
        //     cookie.collect();
        // }
    }
}