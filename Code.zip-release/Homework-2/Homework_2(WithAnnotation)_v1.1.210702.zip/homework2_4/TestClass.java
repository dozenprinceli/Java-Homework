package homework2_4;

/**
 * 测试类TestClass，用于测试Clock类
 */
public class TestClass {
    public static void main(String[] args) {
        Clock time1 = new Clock(12,4,33);
        Clock time2 = new Clock(16,12,6);
        Clock time3 = new Clock(6,48,18);
        
        time1.show();
        time2.show();
        time3.show();
    }
}