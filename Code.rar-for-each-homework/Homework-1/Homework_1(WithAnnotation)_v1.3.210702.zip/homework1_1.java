/**
 * 在屏幕上输出“你好！”
 */
public class homework1_1 {
    
    public static void main(String[] args) {
        System.out.println("你好");
    }

}